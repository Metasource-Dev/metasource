from django.contrib import admin
from .models import Vendor

# Register your models here.
admin.site.register(Vendor)