SET_EMAIL_USE_TLS = True
SET_EMAIL_HOST='smtp.gmail.com'
SET_EMAIL_HOST_USER='sales@metasource.co.in'
SET_EMAIL_HOST_PASSWORD='Salesmetasource@123'
SET_EMAIL_PORT=587
SET_EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
SET_DEFAULT_FROM_EMAIL = 'sales@metasource.co.in'